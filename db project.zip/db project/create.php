<html>
<form id="form1" name="form1" onsubmit="" method="GET">
<br>
<br>
<header><center><b>Add a new Flight</b></center></header>
<br>
<br>
<br>
<br>

Select Airline:&nbsp;
<select name="carrier">
  <option value="11">American Airlines</option>
  <option value="22">United Airlines</option>
  <option value="33">British Airways</option>
  <option value="44">Delta Airlines</option>
  <option value="55">Virgin Atlantic</option>
</select>
<br>
<br>
Flight number: <input type="text" name="fnum"> (e.g XXX)
<br>
<br>
Seat Capacity: &nbsp;<input type="Text" name="capacity">
<br>
<br>
Aircraft type: &nbsp;&nbsp;<input type="text" name="aircraft"> (e.g AXXX, BXXX, MDXX)
<br>
<br>
Origin: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="start"> (e.g DFW, DEL)
<br>
<br>
Destination: &nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="end"> (e.g DFW, DEL)
<br>
<br>
<script type="text/javascript">
    function submitForm(action)
    {
        document.getElementById('form1').action = action;
        document.getElementById('form1').submit();
    }
</script>
<input type="button" onclick="submitForm('create.php')" value="CREATE" />
<input type="button" onclick="submitForm('index.html')" value="BACK" />
<?php
$flight = $_GET["fnum"];
$seat = $_GET["capacity"];
$atype = $_GET["aircraft"];
$origin = $_GET["start"];
$dest = $_GET["end"];
$airline = $_GET["carrier"];


// Create connection
$con=mysqli_connect("localhost","root","abhishek67890","airport_management_system");

$sql = "INSERT INTO flight VALUES('$flight','$seat','$atype','$origin','$dest','$airline')";


mysqli_query($con, $sql);

mysqli_close($con);

?>
</form>
</html>