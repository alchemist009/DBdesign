<html>
<form method="post">
<?php
$flight=$_GET['Flight_no'];
echo $flight;
$con=mysqli_connect("localhost","root","abhishek67890","airport_management_system");

$sql = "DELETE from Flight where Flight_no=$flight";

echo "<br>";

if (!mysqli_query($con,$sql))

{

die('Error: ' . mysqli_error($con));

}

echo "1 record Deleted";

mysqli_close($con);
?>
</form>
</html>