<html>
<form id="form1" name="form1" onsubmit="" method="post">
<?php



$airline=$_GET["anum"];
$flight=$_GET['fnum'];
$seat=$_GET["capacity"];
$aircraft=$_GET['aircraft'];
$origin=$_GET['start'];
$dest=$_GET['end'];
// Create connection
$con=mysqli_connect("localhost","root","abhishek67890","airport_management_system");

$sql = "UPDATE Flight set Seat_capacity=$seat, Aircraft_type='$aircraft', Origin='$origin', Destination='$dest' where Flight_no=$flight";

echo "<br>";

if (!mysqli_query($con,$sql))

{

die('Error: ' . mysqli_error($con));

}

echo "1 record updated";

mysqli_close($con);

?>
<script type="text/javascript">
    function submitForm(action)
    {
        document.getElementById('form1').action = action;
        document.getElementById('form1').submit();
    }
</script>
<br>
<br>
<input type="button" onclick="submitForm('show.php')" value="Show Flights" />
<input type="button" onclick="submitForm('index.html')" value="HOME" />
</form>
</html>