<html>
<form method="post">
<header><center><b>Flight Schedule</b></center></header>
<br>
<br><br><br>

<?php
$con=mysqli_connect("localhost","root","abhishek67890","airport_management_system");

$sql = "SELECT Flight_no,Airline_name, Seat_capacity,Aircraft_type,Origin, Destination FROM flight, Airline where Carrier_ID=C_ID";
$result = $con->query($sql);
//$i=1;
if ($result->num_rows > 0) {
    // output data of each row
	echo "<table border='1'><tr><th>Flight_No</th><th>Airline Name</th><th>Origin</th><th>Destination</th></tr>";
    while($row = $result->fetch_assoc()) {
  //      echo "\t";
	//	echo "Airline Name:  " . $row["Airline_name"]. "        Origin:  " . $row["Origin"]. "  Destination:  " . $row["Destination"]. "<br>";
		
		echo "<tr><td>".$row['Flight_no']."</td><td>".$row['Airline_name']."</td><td>".$row['Origin']."</td><td>".$row['Destination']."</td>";
		echo "<td><a href='show_details.php?Flight_no=".$row['Flight_no']."'>Show</a></td>";
		echo "<td><a href='edit_details.php?Flight_no=".$row['Flight_no']."&Origin=".$row['Origin']."&Seat_capacity=".$row['Seat_capacity']."&Airline_name=".$row['Airline_name']."&Aircraft_type=".$row['Aircraft_type']."&Destination=".$row['Destination']."'>Edit</a></td>";
		echo "<td><a href='delete_details.php?Flight_no=".$row['Flight_no']."'>Delete</a></td></tr>";
	//	echo "<td><input type='submit' name='Flight_no".$numRow."' value='SAVE'/></td></tr>";
		//$i++;
	}
	//$i++;
echo "</table>";
	}


//mysqli_query($con, $sql);

mysqli_close($con);
?>
</form>
</html>