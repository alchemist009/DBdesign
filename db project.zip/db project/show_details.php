<html>
<header><center><b>Show Details of a Flight</b></center></header>
<form id="form1" name="form1" onsubmit="" method="post">
<br>
<br>
<br>
<br>
<br>
<?php
$abc=$_GET['Flight_no'];
$con=mysqli_connect("localhost","root","abhishek67890","airport_management_system");

$sql = "SELECT Flight_no,Airline_name, Seat_capacity,Aircraft_type,Origin, Destination FROM flight, Airline where Carrier_ID=C_ID AND Flight_no=$abc";
$result = $con->query($sql);
//$i=1;
if ($result->num_rows > 0) {
    // output data of each row
	echo "<table border='1'><tr><th>Flight_No</th><th>Airline Name</th><th>Seat Capacity</th><th>Aircraft Type</th><th>Origin</th><th>Destination</th></tr>";
    while($row = $result->fetch_assoc()) {
  //      echo "\t";
	//	echo "Airline Name:  " . $row["Airline_name"]. "        Origin:  " . $row["Origin"]. "  Destination:  " . $row["Destination"]. "<br>";
		
		echo "<tr><td>".$row['Flight_no']."</td><td>".$row['Airline_name']."</td><td>".$row['Seat_capacity']."</td><td>".$row['Aircraft_type']."</td><td>".$row['Origin']."</td><td>".$row['Destination']."</td><tr>";
		
	//	echo "<td><input type='submit' name='Flight_no".$numRow."' value='SAVE'/></td></tr>";
		//$i++;
	}
	//$i++;
echo "</table>";
	}

mysqli_close($con);
?>
<script type="text/javascript">
    function submitForm(action)
    {
        document.getElementById('form1').action = action;
        document.getElementById('form1').submit();
    }
</script>
<br>
<br>
<input type="button" onclick="submitForm('show.php')" value="BACK" />
<input type="button" onclick="submitForm('index.html')" value="HOME" />
</form>
</html>