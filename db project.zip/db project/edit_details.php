<html>
<header><center><b>Edit Details of a Flight</b></center></header>
<form id="form1" name="form1" onsubmit="" method="get">
<br>
<br>
<br>
<br>
<br>
<?php
$airline=$_GET['Airline_name'];
$flight=$_GET['Flight_no'];
$seat=$_GET['Seat_capacity'];
$aircraft=$_GET['Aircraft_type'];
$origin=$_GET['Origin'];
$dest=$_GET['Destination'];
echo "Airline Name:";
echo "&nbsp";
echo "&nbsp";
echo "<input type='text' name='anum' value=$airline readonly>";
echo "<br>";
echo "<br>";
echo "Flight Number:"; 
echo "<input type='text' name='fnum' value=$flight readonly>";
echo "<br>";
echo "<br>";
echo "Seat Capacity:";
echo "&nbsp";
echo "<input type='Text' name='capacity' value=$seat>";
echo "<br>";
echo "<br>";
echo "Aircraft type:";
echo "&nbsp";echo "&nbsp";
echo "<input type='text' name='aircraft' value=$aircraft>";
echo "<br>";
echo "<br>";
echo "Origin:";
echo "&nbsp";echo "&nbsp";echo "&nbsp";echo "&nbsp";echo "&nbsp";echo "&nbsp";echo "&nbsp";echo "&nbsp";echo "&nbsp";echo "&nbsp";echo "&nbsp";echo "&nbsp";
echo "<input type='text' name='start' value=$origin>";
echo "<br>";
echo "<br>";
echo "Destination:"; 
echo "&nbsp";echo "&nbsp";echo "&nbsp";echo "&nbsp";
echo "<input type='text' name='end' value=$dest>";
echo "<br>";
echo "<br>";
?>
<script type="text/javascript">
    function submitForm(action)
    {
        document.getElementById('form1').action = action;
        document.getElementById('form1').submit();
    }
</script>
<input type="button" onclick="submitForm('update.php')" value="UPDATE" />
<input type="button" onclick="submitForm('show.php')" value="BACK" />
<input type="button" onclick="submitForm('index.html')" value="HOME" />


</form>
</html>